# Create a couple of Places:
from .models import Restaurant, Waiter, Place

p1 = Place(name='Demon Dogs', address='944 W. Fullerton')
p1.save()
p2 = Place(name='Ace Hardware', address='1013 N. Ashland')
p2.save()


# Create a Restaurant. Pass the ID of the “parent” object as this object’s ID:

r = Restaurant(place=p1, serves_hot_dogs=True, serves_pizza=False)
r.save()

# A Restaurant can access its place:
r.place


# A Place can access its restaurant, if available:
p1.restaurant


# Set the place using assignment notation.
# Because place is the primary key on Restaurant, the save will create a new restaurant:

r.place = p2
r.save()
p2.restaurant
r.place

# Set the place back again, using assignment in the reverse direction:

p1.restaurant = r
p1.restaurant


# Place.objects.all() returns all Places, regardless of whether they have Restaurants:

Place.objects.order_by('name')

# Quering the model

Restaurant.objects.get(place=p1)
Restaurant.objects.get(place__pk=1)
Restaurant.objects.filter(place__name__startswith="Demon")
Restaurant.objects.exclude(place__address__contains="Ashland")

# This of course works in reverse:

Place.objects.get(pk=1)
Place.objects.get(restaurant__place=p1)
Place.objects.get(restaurant=r)
Place.objects.get(restaurant__place__name__startswith="Demon")

#Add a Waiter to the Restaurant:

w = r.waiter_set.create(name='Joe')
w

#Query the waiters:

Waiter.objects.filter(restaurant__place=p1)
Waiter.objects.filter(restaurant__place__name__startswith="Demon")
