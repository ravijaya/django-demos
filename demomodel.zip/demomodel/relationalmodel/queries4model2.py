from .models2 import Article, Reporter

# Create a few Reporters:

r = Reporter(first_name='John', last_name='Smith', email='john@example.com')
r.save()

r2 = Reporter(first_name='Paul', last_name='Jones', email='paul@example.com')
r2.save()

#Create an Article:

from datetime import date
a = Article(id=None, headline="This is a test", pub_date=date(2005, 7, 27), reporter=r)
a.save()

a.reporter.id
a.reporter
r = a.reporter

# Create an Article via the Reporter object:

new_article = r.article_set.create(headline="John's second story", pub_date=date(2005, 7, 29))
new_article
new_article.reporter
new_article.reporter.id


# Create a new article, and add it to the article set:

new_article2 = Article.objects.create(headline="Paul's story", pub_date=date(2006, 1, 17))
r.article_set.add(new_article2)
new_article2.reporter

new_article2.reporter.id

r.article_set.all()


# Find all Articles for any Reporter whose first name is "John".
Article.objects.filter(reporter__first_name='John')

# Query twice over the related field. This translates to an AND condition in the WHERE clause:
Article.objects.filter(reporter__first_name='John', reporter__last_name='Smith')


# For the related lookup you can supply a primary key value or pass the related object explicitly:

Article.objects.filter(reporter__pk=1)
Article.objects.filter(reporter=1)
Article.objects.filter(reporter__in=[1,2]).distinct()
Article.objects.filter(reporter__in=[r,r2]).distinct()

# You can also use a queryset instead of a literal list of instances:

Article.objects.filter(reporter__in=Reporter.objects.filter(first_name='John')).distinct()


# Querying in the opposite direction:

Reporter.objects.filter(article__pk=1)
Reporter.objects.filter(article=1)
Reporter.objects.filter(article=a)

Reporter.objects.filter(article__headline__startswith='This')
Reporter.objects.filter(article__headline__startswith='This').distinct()

# Counting in the opposite direction works in conjunction with distinct():

Reporter.objects.filter(article__headline__startswith='This').count()
Reporter.objects.filter(article__headline__startswith='This').distinct().count()

# delete

Article.objects.all()
Reporter.objects.order_by('first_name')
r2.delete()
Article.objects.all()
Reporter.objects.order_by('first_name')

# You can delete using a JOIN in the query:

Reporter.objects.filter(article__headline__startswith='This').delete()
Reporter.objects.all()
Article.objects.all()
