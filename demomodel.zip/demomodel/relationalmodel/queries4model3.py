from .models3 import Article, Publication

# Create a couple of Publications:

p1 = Publication(title='The Python Journal')
p1.save()
p2 = Publication(title='Science News')
p2.save()
p3 = Publication(title='Science Weekly')
p3.save()


#Create an Article:

a1 = Article(headline='Django lets you build Web apps easily')
a1.save()

# Associate the Article with a Publication:
a1.publications.add(p1)

# Create another Article, and set it to appear in both Publications:

a2 = Article(headline='NASA uses Python')
a2.save()
a2.publications.add(p1, p2)
a2.publications.add(p3)


# Article objects have access to their related Publication objects:

a1.publications.all()
a2.publications.all()
p2.article_set.all()
p1.article_set.all()
Publication.objects.get(id=4).article_set.all()

# Many-to-many relationships can be queried using lookups across relationships:

Article.objects.filter(publications__id=1)
Article.objects.filter(publications__pk=1)
Article.objects.filter(publications=1)
Article.objects.filter(publications=p1)
Article.objects.filter(publications__title__startswith="Science")
Article.objects.filter(publications__title__startswith="Science").distinct()


# Reverse m2m queries are supported

Publication.objects.filter(id=1)
Publication.objects.filter(pk=1)
Publication.objects.filter(article__headline__startswith="NASA")

Publication.objects.filter(article__id=1)
Publication.objects.filter(article__pk=1)
Publication.objects.filter(article=1)
Publication.objects.filter(article=a1)


# If we delete a Publication, its Articles won’t be able to access it:

p1.delete()
Publication.objects.all()
a1 = Article.objects.get(pk=1)
a1.publications.all()
