from django.apps import AppConfig


class RelationalmodelConfig(AppConfig):
    name = 'relationalmodel'
